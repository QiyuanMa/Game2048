#include<stdio.h>
#include<windows.h>
#include<stdlib.h>
#include<string.h>

int main(){
int filesize;
  char cache[100] = {};
	char *save;
	FILE *fp = NULL;
	if ((fp = fopen("bestscore.txt", "r")) == NULL) {
		printf("Error");
		fclose(fp);
		return 0;
	}
  fseek(fp,0,SEEK_END);
	filesize = ftell(fp);
	save = (char*)malloc(filesize);
	save[0] = 0;
	rewind(fp);
	while (fgets(cache, 100, fp) != NULL) {
		strcat(save, cache);
	}
	fclose(fp);
  printf("%s",save);
  return 0;
}
